param(
    [string]$OutputPath,
    [string]$TenantURL = "",
    [string]$ConfigFolder = ""
)

$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$csiAvailable = -not [string]::IsNullOrWhiteSpace($TenantURL)

# -- Build form (auto-sizing, matches InvoiceSampleGenerator pattern) --
$form = New-Object System.Windows.Forms.Form
$form.Text = "DemoInvoiceLoader V4 - Run Configuration"
$form.StartPosition = "CenterScreen"
$form.AutoSize = $true
$form.AutoSizeMode = "GrowAndShrink"
$form.MinimumSize = New-Object System.Drawing.Size(480, 300)
$form.MaximizeBox = $false
$form.Font = New-Object System.Drawing.Font("Segoe UI", 9)

$y = 15

function AddLabel([string]$text, [bool]$bold = $false) {
    $lbl = New-Object System.Windows.Forms.Label
    $lbl.Text = $text
    $lbl.Location = New-Object System.Drawing.Point(15, $script:y)
    $lbl.AutoSize = $true
    if ($bold) { $lbl.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold) }
    $form.Controls.Add($lbl)
    $script:y += 20
    return $lbl
}

function AddTextBox([string]$default, [int]$width = 420) {
    $tb = New-Object System.Windows.Forms.TextBox
    $tb.Location = New-Object System.Drawing.Point(15, $script:y)
    $tb.Size = New-Object System.Drawing.Size($width, 23)
    $tb.Text = $default
    $form.Controls.Add($tb)
    $script:y += 30
    return $tb
}

function AddCombo([string[]]$items, [string]$default) {
    $cb = New-Object System.Windows.Forms.ComboBox
    $cb.DropDownStyle = "DropDownList"
    $cb.Location = New-Object System.Drawing.Point(15, $script:y)
    $cb.Size = New-Object System.Drawing.Size(200, 23)
    $cb.Items.AddRange($items)
    $idx = [Array]::IndexOf($items, $default)
    $cb.SelectedIndex = if ($idx -ge 0) { $idx } else { 0 }
    $form.Controls.Add($cb)
    $script:y += 30
    return $cb
}

$defaultInputFolder = if ($ConfigFolder -ne "") { Join-Path $ConfigFolder "Input" } else { "" }

# -- Input Folder --
AddLabel "Input Folder"
$txtFolder = AddTextBox $defaultInputFolder
$btnBrowse = New-Object System.Windows.Forms.Button -Property @{ Text="Browse..."; Location=(New-Object System.Drawing.Point(370, ($y - 30))); Size=(New-Object System.Drawing.Size(75, 23)) }
$txtFolder.Size = New-Object System.Drawing.Size(345, 23)
$btnBrowse.Add_Click({
    $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
    if ($txtFolder.Text) { $dlg.SelectedPath = $txtFolder.Text }
    if ($dlg.ShowDialog() -eq "OK") { $txtFolder.Text = $dlg.SelectedPath }
})
$form.Controls.Add($btnBrowse)

# -- Document Mode --
AddLabel "Document Mode"
$cboMode = AddCombo @("PO", "NON_PO") "PO"

# -- Warehouse --
AddLabel "Warehouse"
$txtWarehouse = AddTextBox "MAIN" 200

# -- Terms --
AddLabel "Terms Code"
$txtTerms = AddTextBox "N30" 200

# -- Separator --
$y += 5
AddLabel "Notifications" $true
$sep = New-Object System.Windows.Forms.Label -Property @{ Location=(New-Object System.Drawing.Point(15, $y)); Size=(New-Object System.Drawing.Size(430, 1)); BorderStyle="Fixed3D" }
$form.Controls.Add($sep)
$y += 10

# -- Notification Mode --
AddLabel "Notification Mode"
$cboNotify = AddCombo @("BATCH_SUMMARY", "PER_DOCUMENT", "NONE") "BATCH_SUMMARY"

# -- User Email --
$lblEmail = AddLabel "Your Email (for notifications)"
$txtEmail = AddTextBox "" 300

# -- Disable notifications if no tenant --
if (-not $csiAvailable) {
    $cboNotify.SelectedIndex = 2  # NONE
    $cboNotify.Enabled = $false
    $txtEmail.Enabled = $false
    $lblEmail.Text = "Your Email (requires tenant connection)"
}

$cboNotify.Add_SelectedIndexChanged({
    $txtEmail.Enabled = $cboNotify.SelectedItem -ne "NONE"
})

# -- Buttons --
$y += 10
$btnOK = New-Object System.Windows.Forms.Button
$btnOK.Text = "OK"
$btnOK.Size = New-Object System.Drawing.Size(100, 32)
$btnOK.Location = New-Object System.Drawing.Point(250, $y)
$btnOK.DialogResult = [System.Windows.Forms.DialogResult]::OK
$form.AcceptButton = $btnOK
$form.Controls.Add($btnOK)

$btnCancel = New-Object System.Windows.Forms.Button
$btnCancel.Text = "Cancel"
$btnCancel.Size = New-Object System.Drawing.Size(100, 32)
$btnCancel.Location = New-Object System.Drawing.Point(360, $y)
$btnCancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
$form.CancelButton = $btnCancel
$form.Controls.Add($btnCancel)

# Spacer for auto-size
$spacer = New-Object System.Windows.Forms.Label
$spacer.Location = New-Object System.Drawing.Point(0, ($y + 45))
$spacer.Size = New-Object System.Drawing.Size(470, 1)
$form.Controls.Add($spacer)

# -- Show --
$result = $form.ShowDialog()

if ($result -eq [System.Windows.Forms.DialogResult]::OK) {
    $output = @{
        inputFolderPath  = $txtFolder.Text
        documentMode     = $cboMode.SelectedItem.ToString()
        warehouse        = $txtWarehouse.Text
        terms            = $txtTerms.Text
        notificationMode = $cboNotify.SelectedItem.ToString()
        userEmail        = $txtEmail.Text
        cancelled        = $false
    }
} else {
    $output = @{ cancelled = $true }
}

$output | ConvertTo-Json | Out-File -FilePath $OutputPath -Encoding UTF8
