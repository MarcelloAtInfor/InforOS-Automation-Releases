#!/usr/bin/env python3
"""Render invoices with live CSI lookups enabled.

Sets the required environment variables and delegates to render_invoice_batch.py.
All arguments are passed through.

Usage:
  python scripts/render_with_csi.py --ionapi <path> --request-json <path> --output-folder <path>
"""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

RENDERER = Path(__file__).resolve().parent / "render_invoice_batch.py"

DEFAULT_IONAPI = r"C:\Users\mmartins1\OneDrive - Infor\CREDS\API_CREDS\SLSGDENA049_DEM\OAUTH.ionapi"


def main() -> int:
    args = list(sys.argv[1:])

    # Extract --ionapi if provided, otherwise use default
    ionapi_path = DEFAULT_IONAPI
    if "--ionapi" in args:
        idx = args.index("--ionapi")
        ionapi_path = args[idx + 1]
        args = args[:idx] + args[idx + 2:]

    os.environ["CSI_LOOKUP_ENABLED"] = "1"
    os.environ["IONAPI_FILE"] = ionapi_path

    return subprocess.call([sys.executable, str(RENDERER)] + args)


if __name__ == "__main__":
    sys.exit(main())
