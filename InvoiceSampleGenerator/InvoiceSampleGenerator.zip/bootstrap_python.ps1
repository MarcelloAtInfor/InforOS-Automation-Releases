Add-Type -AssemblyName System.Windows.Forms

trap {
    Write-Host "UNEXPECTED ERROR: $_"
    [System.Windows.Forms.MessageBox]::Show("Unexpected error during setup:`n`n$_", "InvoiceSampleGenerator - Setup Required", "OK", "Warning") | Out-Null
    Write-Host "Press any key to close..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    exit 1
}

function Show-Error([string]$msg) {
    [System.Windows.Forms.MessageBox]::Show($msg, "InvoiceSampleGenerator - Setup Required", "OK", "Warning") | Out-Null
}

function Find-PythonExe {
    # Search known install locations for a real python.exe (not the WindowsApps stub)
    $locations = @(
        "$env:LOCALAPPDATA\Programs\Python\Python3*\python.exe"
        "C:\Python3*\python.exe"
        "C:\Program Files\Python3*\python.exe"
    )
    foreach ($pattern in $locations) {
        $found = Get-ChildItem -Path $pattern -ErrorAction SilentlyContinue | Sort-Object Name -Descending | Select-Object -First 1
        if ($found) {
            # Verify it actually runs
            $out = cmd /c """$($found.FullName)"" --version" 2>&1
            if ($LASTEXITCODE -eq 0 -and "$out" -match "Python 3\.") {
                return $found.FullName
            }
        }
    }
    return $null
}

function Ensure-PythonOnPath([string]$pythonExe) {
    # Add Python's directory to User PATH if not already there
    $pythonDir = Split-Path -Parent $pythonExe
    $scriptsDir = Join-Path $pythonDir "Scripts"
    $userPath = [Environment]::GetEnvironmentVariable("Path", "User")
    
    $needsUpdate = $false
    if ($userPath -notlike "*$pythonDir*") {
        $userPath = "$pythonDir;$userPath"
        $needsUpdate = $true
    }
    if ($userPath -notlike "*$scriptsDir*") {
        $userPath = "$scriptsDir;$userPath"
        $needsUpdate = $true
    }
    
    if ($needsUpdate) {
        Write-Host "  Adding Python to User PATH..."
        [Environment]::SetEnvironmentVariable("Path", $userPath, "User")
        # Also update current session
        $env:Path = "$pythonDir;$scriptsDir;$env:Path"
        Write-Host "  PATH updated. Note: RPA Studio must be restarted for the built-in Python activity to see this change."
    }
}

# --- Step 1: Check if python works from PATH ---
Write-Host "Checking for Python..."
$pythonWorks = $false
try {
    $out = cmd /c "python --version" 2>&1
    if ($LASTEXITCODE -eq 0 -and "$out" -match "Python 3\.") {
        Write-Host "  Found: $out"
        $pythonWorks = $true
    }
} catch { }

# --- Step 2: If not on PATH, search install locations ---
$pythonExe = $null
if (-not $pythonWorks) {
    $pythonExe = Find-PythonExe
    if ($pythonExe) {
        Write-Host "  Found installed but not on PATH: $pythonExe"
        Ensure-PythonOnPath $pythonExe
        $pythonWorks = $true
    }
}

# --- Step 3: If not installed at all, install via winget ---
if (-not $pythonWorks) {
    Write-Host "  Python not found. Attempting install via winget..."
    try {
        cmd /c "winget --version" 2>&1 | Out-Null
        if ($LASTEXITCODE -ne 0) { throw "winget not available" }
        Write-Host "  Running: winget install Python.Python.3.13 --silent"
        cmd /c "winget install Python.Python.3.13 --accept-package-agreements --accept-source-agreements --silent" 2>&1 | ForEach-Object { Write-Host "  $_" }
    } catch {
        Write-Host "  winget failed: $_"
    }

    # Search again after install
    $pythonExe = Find-PythonExe
    if ($pythonExe) {
        Write-Host "  Installed: $pythonExe"
        Ensure-PythonOnPath $pythonExe
        $pythonWorks = $true
    }
}

if (-not $pythonWorks) {
    $msg = "Python 3.11+ is required but could not be installed automatically.`n`nPlease install Python from python.org or the Windows Store and re-run.`n`nAfter installing, restart RPA Studio."
    Show-Error $msg
    Write-Host "`nERROR: $msg"
    Write-Host "Press any key to close..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    exit 1
}

# --- Step 4: Determine which python command to use for pip ---
# Use the explicit path if we found one, otherwise use PATH
if ($pythonExe) {
    $pipCmd = $pythonExe
} else {
    $pipCmd = "python"
}

# --- Step 5: Install reportlab ---
Write-Host "Ensuring reportlab is installed..."
Write-Host "  Running: $pipCmd -m pip install reportlab"
$pipOut = cmd /c """$pipCmd"" -m pip install reportlab 2>&1"
Write-Host $pipOut
if ($LASTEXITCODE -ne 0) {
    $msg = "Failed to install Python package 'reportlab'.`n`nTry running manually:`n  $pipCmd -m pip install reportlab"
    Show-Error $msg
    Write-Host "`nERROR: $msg"
    Write-Host "Press any key to close..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    exit 1
}
Write-Host "  reportlab ready."

# --- Step 6: Check if Studio needs restart ---
# If we had to add Python to PATH, the InvokePythonScript activity won't see it
# until Studio is restarted. Warn the user.
if ($pythonExe) {
    $msg = "Python setup complete.`n`nIMPORTANT: Please close and reopen RPA Studio so it can detect Python, then run again."
    [System.Windows.Forms.MessageBox]::Show($msg, "InvoiceSampleGenerator - Restart Required", "OK", "Information") | Out-Null
    Write-Host "`n$msg"
    exit 1
}

Write-Host "Bootstrap complete."
exit 0
